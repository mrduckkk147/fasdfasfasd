# EasyInstallerV2

Credits to [Ender](https://github.com/Ender-0001/) for writing the code, [blk](https://github.com/simplyblk) for providing servers.

Based off of [Kyiro's EasyInstaller](https://github.com/Kyiro/Fortnite-ManifestsArchive)

Download [here](https://github.com/simplyblk/EasyInstallerV2/releases)
